package application.project.Social.Login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
